# -*- coding = utf-8 -*-

from flask import Flask, request, render_template
from flask import redirect, url_for

app = Flask(__name__)
input_info = input("菜名：")

@app.route('/')
def welcome():
	return render_template('cover.html')

@app.route('/recipe')
def recipe():
	return render_template('recipe.html')

@app.route('/index', methods=['GET','POST'])
def index():
	return redirect(url_for('recipe'))

if request.method == 'POST':
	search_button = request.form["菜谱搜索"]
		return index()

def function():
	List_recipe = {"鱼香肉丝":url_for('recipe')}
	if input_info == "鱼香肉丝":


if __name__ == "__main__":
	app.run()(debug = True)	


